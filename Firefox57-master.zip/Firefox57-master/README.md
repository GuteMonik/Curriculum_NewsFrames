![Firefox 57](https://blog.nightly.mozilla.org/files/2017/07/nightly-blog-header-robot-2.jpg)
# Sprint Firefox 57 en Colombia
La versión de Firefox 57 cada vez está más cerca. Por esta razón, queremos presentarla y asegurarnos de su éxito e impacto. Nos encontramos ahora en la introducción de la campaña de Firefox 57. 

Durante esta campaña las comunidades locales nos vamos a reunir y nos aseguraremos que Firefox se ejecute sin problemas en cada región. 
En este repositorio se presenta la información sobre el evento en el que se testeará Firefox 57 en Colombia. La descripción del trabajo, las actividades realizadas y también toda la documentación. 
* [Registro](Registro.md)
* [Actividades](Actividades.md)
* [Formato de las actividades y Documentación](Formato_Documentación.md)
* [Reportes](Reportes.md)
* [Recursos](Recursos.md)

![Global Sprint](https://cloud.githubusercontent.com/assets/617994/24632585/b2b07dcc-1892-11e7-91cf-f9e473187cf7.png)
