# Registro

¡Hola! 

¿Quieres participar de las pruebas de Firefox 57 en Colombia? Te invitamos a participar y contribuir. 

Tus esfuerzos ayudarán a que el lanzamiento de [Firefox](https://www.mozilla.org/en-US/firefox/) en Colombia se una éxito. Tenemos tres puntos en donde estaremos hablando, haciendo pruebas y trabajando para que Firefox sea mejor.
* Universidad Nacional
* Universidad Distrital
* Reunión en línea

Te invitamos a registrarte como participante de la actividad a través del [Formulario de participación](https://docs.google.com/forms/d/e/1FAIpQLScy-P6m4pDx_Qylpe3No_bkbh3REoDXf-7YLne7nY8CKs7S6w/viewform?usp=sf_link). De igual forma, si te interesa participar de las actividades de la Comunidad Local de Mozilla en Colombia, quieres organizar o realizar algún evento, puedes ponerte en contacto con nosotros a través de nuestra [FanPage](https://www.facebook.com/MozColombia/), el [Formulario de Contacto](https://goo.gl/forms/SeABprM3iGLspBfp2) o hablando con alguno de nuestros [Representantes](https://reps.mozilla.org/people/#/search/colombia/).

¡Bienvenido y sigamos construyendo juntos una Web Mejor!
